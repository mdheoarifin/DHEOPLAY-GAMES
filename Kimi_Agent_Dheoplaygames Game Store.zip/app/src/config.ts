// =============================================================================
// Site Configuration - DHEOPLAY GAMES
// Edit ONLY this file to customize all content across the site.
// All animations, layouts, and styles are controlled by the components.
// =============================================================================

// -- Site-wide settings -------------------------------------------------------
export interface SiteConfig {
  title: string;
  description: string;
  language: string;
}

export const siteConfig: SiteConfig = {
  title: "DHEOPLAY GAMES - Top Up Game Terpercaya",
  description: "DHEOPLAY GAMES - Toko top up game online terpercaya. Tersedia Mobile Legends, Free Fire, PUBG Mobile, Genshin Impact, dan banyak game populer lainnya. Hubungi 081277331274.",
  language: "id",
};

// -- Hero Section -------------------------------------------------------------
export interface HeroNavItem {
  label: string;
  sectionId: string;
  icon: "disc" | "play" | "calendar" | "music";
}

export interface HeroConfig {
  backgroundImage: string;
  brandName: string;
  decodeText: string;
  decodeChars: string;
  subtitle: string;
  ctaPrimary: string;
  ctaPrimaryTarget: string;
  ctaSecondary: string;
  ctaSecondaryTarget: string;
  cornerLabel: string;
  cornerDetail: string;
  navItems: HeroNavItem[];
}

export const heroConfig: HeroConfig = {
  backgroundImage: "/images/hero-bg.jpg",
  brandName: "DHEOPLAY",
  decodeText: "TOP UP GAME",
  decodeChars: "TOPUPGAMES2024",
  subtitle: "Top up diamond, UC, dan currency game favoritmu dengan harga terbaik. Proses cepat, aman, dan terpercaya.",
  ctaPrimary: "Lihat Game",
  ctaPrimaryTarget: "games",
  ctaSecondary: "Hubungi Kami",
  ctaSecondaryTarget: "contact",
  cornerLabel: "WhatsApp",
  cornerDetail: "081277331274",
  navItems: [
    { label: "Game Populer", sectionId: "games", icon: "disc" },
    { label: "Galeri", sectionId: "gallery", icon: "play" },
    { label: "Promo", sectionId: "promo", icon: "calendar" },
    { label: "Kontak", sectionId: "contact", icon: "music" },
  ],
};

// -- Album Cube Section (Featured Games) -------------------------------------------------------
export interface Album {
  id: number;
  title: string;
  subtitle: string;
  image: string;
}

export interface AlbumCubeConfig {
  albums: Album[];
  cubeTextures: string[];
  scrollHint: string;
}

export const albumCubeConfig: AlbumCubeConfig = {
  albums: [
    {
      id: 1,
      title: "MOBILE LEGENDS",
      subtitle: "DIAMONDS",
      image: "/images/mobile-legends.jpg",
    },
    {
      id: 2,
      title: "FREE FIRE",
      subtitle: "DIAMONDS",
      image: "/images/free-fire.jpg",
    },
    {
      id: 3,
      title: "PUBG MOBILE",
      subtitle: "UC",
      image: "/images/pubg-mobile.jpg",
    },
    {
      id: 4,
      title: "GENSHIN IMPACT",
      subtitle: "GENESIS CRYSTALS",
      image: "/images/genshin-impact.jpg",
    },
  ],
  cubeTextures: [
    "/images/mobile-legends.jpg",
    "/images/free-fire.jpg",
    "/images/pubg-mobile.jpg",
    "/images/genshin-impact.jpg",
    "/images/honor-of-kings.jpg",
    "/images/honkai-star-rail.jpg",
  ],
  scrollHint: "Scroll untuk melihat lebih banyak game",
};

// -- Parallax Gallery Section -------------------------------------------------
export interface ParallaxImage {
  id: number;
  src: string;
  alt: string;
}

export interface GalleryImage {
  id: number;
  src: string;
  title: string;
  date: string;
}

export interface ParallaxGalleryConfig {
  sectionLabel: string;
  sectionTitle: string;
  galleryLabel: string;
  galleryTitle: string;
  marqueeTexts: string[];
  endCtaText: string;
  parallaxImagesTop: ParallaxImage[];
  parallaxImagesBottom: ParallaxImage[];
  galleryImages: GalleryImage[];
}

export const parallaxGalleryConfig: ParallaxGalleryConfig = {
  sectionLabel: "Koleksi Game",
  sectionTitle: "SEMUA GAME POPULER",
  galleryLabel: "Galeri",
  galleryTitle: "JELAJAHI DUNIA GAMING",
  marqueeTexts: [
    "MOBILE LEGENDS",
    "FREE FIRE",
    "PUBG MOBILE",
    "GENSHIN IMPACT",
    "HONOR OF KINGS",
    "HONKAI STAR RAIL",
    "MARVEL RIVALS",
    "VALORANT",
    "FORTNITE",
    "ROBLOX",
  ],
  endCtaText: "Top Up Sekarang",
  parallaxImagesTop: [
    { id: 1, src: "/images/valorant.jpg", alt: "Valorant" },
    { id: 2, src: "/images/fortnite.jpg", alt: "Fortnite" },
    { id: 3, src: "/images/roblox.jpg", alt: "Roblox" },
    { id: 4, src: "/images/clash-of-clans.jpg", alt: "Clash of Clans" },
    { id: 5, src: "/images/clash-royale.jpg", alt: "Clash Royale" },
    { id: 6, src: "/images/cod-mobile.webp", alt: "Call of Duty Mobile" },
  ],
  parallaxImagesBottom: [
    { id: 1, src: "/images/marvel-rivals.jpg", alt: "Marvel Rivals" },
    { id: 2, src: "/images/marvel-future-fight.jpg", alt: "Marvel Future Fight" },
    { id: 3, src: "/images/marvel-contest-champions.jpg", alt: "Marvel Contest of Champions" },
    { id: 4, src: "/images/wuthering-waves.jpg", alt: "Wuthering Waves" },
    { id: 5, src: "/images/steam-wallet.jpg", alt: "Steam Wallet" },
    { id: 6, src: "/images/delta-force.jpg", alt: "Delta Force" },
  ],
  galleryImages: [
    { id: 1, src: "/images/mobile-legends.jpg", title: "Mobile Legends", date: "Diamonds" },
    { id: 2, src: "/images/free-fire.jpg", title: "Free Fire", date: "Diamonds" },
    { id: 3, src: "/images/pubg-mobile.jpg", title: "PUBG Mobile", date: "UC" },
    { id: 4, src: "/images/genshin-impact.jpg", title: "Genshin Impact", date: "Genesis Crystals" },
    { id: 5, src: "/images/honor-of-kings.jpg", title: "Honor of Kings", date: "Tokens" },
    { id: 6, src: "/images/honkai-star-rail.jpg", title: "Honkai Star Rail", date: "Oneiric Shards" },
  ],
};

// -- Tour Schedule Section (Promo/Offers) ----------------------------------------------------
export interface TourDate {
  id: number;
  date: string;
  time: string;
  city: string;
  venue: string;
  status: "on-sale" | "sold-out" | "coming-soon";
  image: string;
}

export interface TourStatusLabels {
  onSale: string;
  soldOut: string;
  comingSoon: string;
  default: string;
}

export interface TourScheduleConfig {
  sectionLabel: string;
  sectionTitle: string;
  vinylImage: string;
  buyButtonText: string;
  detailsButtonText: string;
  bottomNote: string;
  bottomCtaText: string;
  statusLabels: TourStatusLabels;
  tourDates: TourDate[];
}

export const tourScheduleConfig: TourScheduleConfig = {
  sectionLabel: "Penawaran Spesial",
  sectionTitle: "PROMO TOP UP",
  vinylImage: "/images/gaming-token.png",
  buyButtonText: "Pesan Sekarang",
  detailsButtonText: "Detail",
  bottomNote: "Hubungi kami untuk informasi lebih lanjut",
  bottomCtaText: "WhatsApp: 081277331274",
  statusLabels: {
    onSale: "Tersedia",
    soldOut: "Habis",
    comingSoon: "Segera",
    default: "Hubungi",
  },
  tourDates: [
    {
      id: 1,
      date: "2025.02.15",
      time: "24/7",
      city: "Mobile Legends",
      venue: "Diamond x86 - Rp 20.000",
      status: "on-sale",
      image: "/images/mobile-legends.jpg",
    },
    {
      id: 2,
      date: "2025.02.15",
      time: "24/7",
      city: "Free Fire",
      venue: "Diamond 100 - Rp 15.000",
      status: "on-sale",
      image: "/images/free-fire.jpg",
    },
    {
      id: 3,
      date: "2025.02.15",
      time: "24/7",
      city: "PUBG Mobile",
      venue: "UC 60 - Rp 15.000",
      status: "on-sale",
      image: "/images/pubg-mobile.jpg",
    },
    {
      id: 4,
      date: "2025.02.15",
      time: "24/7",
      city: "Genshin Impact",
      venue: "Genesis 60 - Rp 15.000",
      status: "on-sale",
      image: "/images/genshin-impact.jpg",
    },
    {
      id: 5,
      date: "2025.02.15",
      time: "24/7",
      city: "Honor of Kings",
      venue: "Token 100 - Rp 18.000",
      status: "on-sale",
      image: "/images/honor-of-kings.jpg",
    },
    {
      id: 6,
      date: "2025.02.15",
      time: "24/7",
      city: "Honkai Star Rail",
      venue: "Oneiric 60 - Rp 15.000",
      status: "on-sale",
      image: "/images/honkai-star-rail.jpg",
    },
    {
      id: 7,
      date: "2025.02.15",
      time: "24/7",
      city: "Marvel Future Fight",
      venue: "Crystal 100 - Rp 20.000",
      status: "on-sale",
      image: "/images/marvel-future-fight.jpg",
    },
    {
      id: 8,
      date: "2025.02.15",
      time: "24/7",
      city: "Wuthering Waves",
      venue: "Lunite 60 - Rp 15.000",
      status: "on-sale",
      image: "/images/wuthering-waves.jpg",
    },
    {
      id: 9,
      date: "2025.02.15",
      time: "24/7",
      city: "Marvel Rivals",
      venue: "Unit 200 - Rp 25.000",
      status: "on-sale",
      image: "/images/marvel-rivals.jpg",
    },
    {
      id: 10,
      date: "2025.02.15",
      time: "24/7",
      city: "Marvel Contest of Champions",
      venue: "Unit 100 - Rp 20.000",
      status: "on-sale",
      image: "/images/marvel-contest-champions.jpg",
    },
    {
      id: 11,
      date: "2025.02.15",
      time: "24/7",
      city: "Valorant",
      venue: "VP 100 - Rp 15.000",
      status: "on-sale",
      image: "/images/valorant.jpg",
    },
    {
      id: 12,
      date: "2025.02.15",
      time: "24/7",
      city: "Fortnite",
      venue: "V-Bucks 1000 - Rp 18.000",
      status: "on-sale",
      image: "/images/fortnite.jpg",
    },
    {
      id: 13,
      date: "2025.02.15",
      time: "24/7",
      city: "Roblox",
      venue: "Robux 400 - Rp 20.000",
      status: "on-sale",
      image: "/images/roblox.jpg",
    },
    {
      id: 14,
      date: "2025.02.15",
      time: "24/7",
      city: "Delta Force",
      venue: "Credits 500 - Rp 25.000",
      status: "on-sale",
      image: "/images/delta-force.jpg",
    },
    {
      id: 15,
      date: "2025.02.15",
      time: "24/7",
      city: "Call of Duty Mobile",
      venue: "CP 80 - Rp 15.000",
      status: "on-sale",
      image: "/images/cod-mobile.webp",
    },
    {
      id: 16,
      date: "2025.02.15",
      time: "24/7",
      city: "Clash of Clans",
      venue: "Gems 500 - Rp 20.000",
      status: "on-sale",
      image: "/images/clash-of-clans.jpg",
    },
    {
      id: 17,
      date: "2025.02.15",
      time: "24/7",
      city: "Clash Royale",
      venue: "Gems 500 - Rp 20.000",
      status: "on-sale",
      image: "/images/clash-royale.jpg",
    },
  ],
};

// -- Footer Section -----------------------------------------------------------
export interface FooterImage {
  id: number;
  src: string;
}

export interface SocialLink {
  icon: "instagram" | "twitter" | "youtube" | "music";
  label: string;
  href: string;
}

export interface FooterConfig {
  portraitImage: string;
  portraitAlt: string;
  heroTitle: string;
  heroSubtitle: string;
  artistLabel: string;
  artistName: string;
  artistSubtitle: string;
  brandName: string;
  brandDescription: string;
  quickLinksTitle: string;
  quickLinks: string[];
  contactTitle: string;
  emailLabel: string;
  email: string;
  phoneLabel: string;
  phone: string;
  addressLabel: string;
  address: string;
  newsletterTitle: string;
  newsletterDescription: string;
  newsletterButtonText: string;
  subscribeAlertMessage: string;
  copyrightText: string;
  bottomLinks: string[];
  socialLinks: SocialLink[];
  galleryImages: FooterImage[];
}

export const footerConfig: FooterConfig = {
  portraitImage: "/images/footer-portrait.jpg",
  portraitAlt: "Gaming Experience",
  heroTitle: "DHEOPLAY",
  heroSubtitle: "GAMES",
  artistLabel: "Toko Top Up",
  artistName: "Game Online",
  artistSubtitle: "Terpercaya Sejak 2020",
  brandName: "DHEOPLAY GAMES",
  brandDescription: "Toko top up game online terpercaya dengan harga terbaik. Kami menyediakan berbagai macam game populer dengan proses yang cepat, aman, dan terpercaya.",
  quickLinksTitle: "Game Populer",
  quickLinks: [
    "Mobile Legends",
    "Free Fire",
    "PUBG Mobile",
    "Genshin Impact",
    "Honor of Kings",
    "Honkai Star Rail",
  ],
  contactTitle: "Hubungi Kami",
  emailLabel: "Email",
  email: "dheoplaygames@gmail.com",
  phoneLabel: "WhatsApp",
  phone: "081277331274",
  addressLabel: "Lokasi",
  address: "Delima, Pekanbaru City, Riau",
  newsletterTitle: "Dapatkan Promo",
  newsletterDescription: "Subscribe untuk mendapatkan info promo dan diskon menarik",
  newsletterButtonText: "Subscribe",
  subscribeAlertMessage: "Terima kasih telah subscribe!",
  copyrightText: "© 2025 DHEOPLAY GAMES. All rights reserved.",
  bottomLinks: [
    "Privacy Policy",
    "Terms of Service",
    "Refund Policy",
  ],
  socialLinks: [
    { icon: "instagram", label: "Instagram", href: "#" },
    { icon: "twitter", label: "Twitter", href: "#" },
    { icon: "youtube", label: "YouTube", href: "#" },
    { icon: "music", label: "TikTok", href: "#" },
  ],
  galleryImages: [
    { id: 1, src: "/images/mobile-legends.jpg" },
    { id: 2, src: "/images/free-fire.jpg" },
    { id: 3, src: "/images/pubg-mobile.jpg" },
    { id: 4, src: "/images/genshin-impact.jpg" },
    { id: 5, src: "/images/honor-of-kings.jpg" },
    { id: 6, src: "/images/honkai-star-rail.jpg" },
  ],
};
